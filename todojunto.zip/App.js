import logo from './logo.svg';
import './App.css';
import React from 'react';
import PersonaCard from './Components1/personacard';
import PersonCard1 from './Components1/personcard1';


function App(){
  return (
    <div className="App">
      <PersonaCard firstname={"Jane"} lastname={"Doe,"} age={"44"} haircolor={"hair color: Black"}/>
      <PersonaCard firstname={"John"} lastname={"Smith,"} age={"edad: 88"} haircolor={"hair color: Brown"}/>
      <PersonaCard firstname={"Millard"} lastname={"Fillmore,"} age={"edad: 50"} haircolor={"hair color: Brown"}/>
      <PersonaCard firstname={"Maria"} lastname={"Smith,"} age={"edad: 62"} haircolor={"hair color: Brown"}/>
      <div>
        <ul>
          <li>este es un hijo</li>
        </ul>
        </div>
        <PersonCard1 age={"31"}/>

      

      </div>
  )
}

export default App;
