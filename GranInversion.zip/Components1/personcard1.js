import React, {useState} from "react";

const PersonCard1 = (props)=>{
    const [age, setAge] = useState(props.age)

    const updateStateAge = () =>{
        let newAge = age
        newAge++
        setAge(newAge)
    }

    return(
        <div>
            <p>{props.name}</p>
            <p id="age">{age}</p>
            <button onClick={updateStateAge}>"birthday Button for Jane Doe"</button>
        </div>

    )
}

export default PersonCard1;
