import logo from './logo.svg';
import './App.css';
import React from 'react';
import PersonaCard from './Components1/personacard';


function App() {
  return (
    <div className="App">
      <PersonaCard firstname={"Jane"} lastname={"Doe,"}/>
      <PersonaCard age={"edad: 45"}/>
      <PersonaCard haircolor={"hair color: Black"}/>
      <PersonaCard firstname={"John"} lastname={"Smith,"}/>
      <PersonaCard age={"edad: 88"}/>
      <PersonaCard haircolor={"hair color: Brown"}/>
      <PersonaCard firstname={"Millard"} lastname={"Fillmore,"}/>
      <PersonaCard age={"edad: 50"}/>
      <PersonaCard haircolor={"hair color: Brown"}/>
      <PersonaCard firstname={"Maria"} lastname={"Smith,"}/>
      <PersonaCard age={"edad: 62"}/>
      <PersonaCard haircolor={"hair color: Brown"}/>
      <PersonaCard>
        <ul>
          <li>este es un hijo</li>
        </ul>
      </PersonaCard>
      </div>
  )
}

export default App;
