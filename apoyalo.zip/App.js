import logo from './logo.svg';
import './App.css';
import PersonaCard from './Components1/personacard';
import PersonCard1 from './Components1/personcard1';
import PersonCard2 from './Components1/personcard2';
import PersonCard3 from './Components1/personcard3';

function App() {
  return (
    <div className="App">
      <PersonaCard firstname={"Doe"}/>
      <PersonaCard lastname={"Jane"}/>
      <PersonaCard age={"Age: 45"}/>
      <PersonaCard haircolor={"Hair Color: Black"}/>
      <PersonCard1 firstname={"Smith"}/>
      <PersonCard1 lastname={"John"}/>
      <PersonCard1 age={"Age: 88"}/>
      <PersonCard1 haircolor={"Hair Color: Brown"}/>
      <PersonCard2 firstname={"Fillmore"}/>
      <PersonCard2 lastname={"Millard"}/>
      <PersonCard2 age={"Age: 50"}/>
      <PersonCard2 haircolor={"Hair Color: Brown"}/>
      <PersonCard3 firstname={"Smith"}/>
      <PersonCard3 lastname={"Maria"}/>
      <PersonCard3 age={"Age: 62"}/>
      <PersonCard3 haircolor={"Hair Color: Brown"}/>
      
      </div>
  );
}

export default App;
