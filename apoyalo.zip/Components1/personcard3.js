import React,{Component} from "react";

class PersonCard3 extends Component{
    render(){
        return(
            <div>
            <h1>{this.props.firstname}</h1>
            <h1>{this.props.lastname}</h1>
            <p>{this.props.age}</p>
            <p>{this.props.haircolor}</p>
            </div>
        )
    }
}
export default PersonCard3;