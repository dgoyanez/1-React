import React, {Component} from 'react';

class PersonaCard extends Component{


    render(){

        const { lastname, firstname, age, haircolor}= this.props;


        return(
            <React.Fragment>
            <h1>{lastname} {firstname}</h1>
            <p>{age}</p>
            <p>{haircolor}</p>
            {this.props.children}
            </React.Fragment>
        )
    }
}
export default PersonaCard;