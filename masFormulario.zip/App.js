import './App.css';
import React, { useState } from 'react';
import Swal from 'sweetalert2'
import List from './components/form/list';

const App = () => {

  const [edad, setEdad] = useState(10);
  const [email, setEmail] = useState('');
  

  const aumentar = (e) =>{
    setEdad(edad+1);
  }
  const disminuir = (e) =>{
    if (edad == 0) {
      Swal.fire("edad invalida", 'la edad no puede ser menor a 0', 'warning');
    } else{
    setEdad(edad-1);
  } 
  }
  return (
    <div>
      <ul >
        <li>la edad es:{edad}</li>
        <li><button type='button' onClick={aumentar}>aumentar</button></li>
        <li><button type='button' onClick={disminuir}>disminuir</button></li>
      </ul>
      <div>
        <List></List>
      </div>
    </div>
  );
}

export default App;
