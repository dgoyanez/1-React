import { useState } from "react";
import Swal from 'sweetalert2'

const Formulario = props =>{

    const [name, setName] = useState('');
    const [nameError, setNameError] = useState('');
    const [lastname, setLastName] = useState('');
    const [lastError, setLastError] = useState ('');
    const [email, setEmail] = useState('');
    const [emailError, setEmailError] = useState ('');
    const [pass, setPass] = useState('');
    const [passError, setPassError] = useState ('');
    const [pass2, setPass2] = useState('');
    const [pass2Error, setPass2Error] = useState ('');
   

    // const actualizarNombre = (e) =>{
    //     setName(e.target.value);
    // }

    const enviar = (e) =>{
        e.preventDefault();
        let errormessage = ""
        if (name.length < 3){setNameError("debe tener minimo 3 caracteres")
            // errormessage = errormessage + "nombre debe tener al menos 3 caracteres \n"
            // Swal.fire("nombre invalido", 'nombre debe tener almenos 3 caracteres', 'warning');
        }else {setNameError("")}

        if (lastname.length < 3){setLastError("debe tener minimo 3 caracteres")
            // errormessage = errormessage + "lastname debe tener al menos 3 caracteres \n"
            // Swal.fire("lastname invalido", 'Lastname debe tener almenos 3 caracteres', 'warning');
        }else{setLastError("")}
        //  if (errormessage.length > 0){
        //     Swal.fire("errores", errormessage, 'warning')
        // }
        if (email.length < 5){setEmailError("debe tener minimo 5 caracteres")}
        else{setEmailError("")}
        if (pass.length < 5){setPassError("debe tener minimo 5 caracteres")}
        else{setPassError("")}
        if (pass.length < 5){setPassError("debe tener minimo 5 caracteres")}
        else{setPassError("")}
        if (pass2.length == pass.length){setPass2Error("debe ser igual a contraseña")}
        else{setPass2Error("")}
        

    }

    return(
        <form onSubmit={enviar}>
            <label>your name:<input type={"text"} placeholder={"...name"} value={name} onChange={ (e) => setName(e.target.value)}/></label>
            {nameError.length > 0? <p>{nameError}</p>: ""}
            <label>your lastname:<input type={"text"} placeholder={"...lastname"}onChange={ (e) => setLastName(e.target.value)}/></label>
            {lastError.length > 0? <p>{lastError}</p>: ""}
            <label>your email:<input type={"email"} placeholder={"...email"}onChange={ (e) => setEmail(e.target.value)}/></label>
            {emailError.length > 0? <p>{emailError}</p>: ""}
            <label>your password:<input type={"password"} placeholder={"...password"}onChange={ (e) => setPass(e.target.value)}/></label>
            {passError.length > 0? <p>{passError}</p>: ""}
            <label>your Confirm password:<input type={"password"} placeholder={"...Confirm password"}onChange={ (e) => setPass2(e.target.value)}/></label>
            {pass2Error.length == passError.length? <p>{pass2Error}</p>: ""}
            <button type="submit">enviar</button>
        </form>
    );
}
export default Formulario;