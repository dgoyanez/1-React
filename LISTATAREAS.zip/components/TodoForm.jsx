import React from 'react'
import { useState } from 'react';

 function TodoForm({addtodo}) {

   const [userInput, setUserInput] = useState();

   const cambiaTexto = (e) =>{
        setUserInput(e.currentTarget.value);
   }

   const handleSubmit = (e) =>{
       e.preventDefault();
       if(userInput.trim() !== ''){
           addtodo(userInput);
           setUserInput('');
       }

   }

  return (
    <div style={{margin:20}}>
        <form onSubmit={handleSubmit}>
            <input type={"text"} value={userInput} onChange={cambiaTexto}/>
            <button>Agregar Tarea</button>
        </form>
    </div>
  )
}
export default TodoForm;
