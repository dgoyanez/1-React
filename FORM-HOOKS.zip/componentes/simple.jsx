const Simple = (props) =>{
    return(
        <div>{props.message}</div>
    )
}

export default Simple;