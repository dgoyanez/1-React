import './App.css';
import React, { useState } from 'react';
import Simple from './componentes/simple';

function App(){

const [email, setEmail] = useState()
  const [cambiar, setCambiar] = useState()
  const [apellido, setApellido] = useState()
  const [clave, setClave] = useState()
  const [validar, setValidar] = useState()
  const handleSubmit = (e) =>{
    e.preventDefault()
  }

const handleChange = (e) =>{
  if (e.target.name == "cambiar"){
  setCambiar(e.target.value)
} if (e.target.name == "email"){
  setEmail(e.target.value)
} if (e.target.name == "apellido"){
  setApellido(e.target.value)
} if (e.target.name == "clave"){
  setClave(e.target.value)
} if (e.target.name == "validar"){
  setValidar(e.target.value)
} 
}


  return(
    <div className='App'>
      <form onSubmit={handleSubmit}>
        <label>name:</label>
        <input onChange={(e)=>handleChange(e)} type={"text"} name={"cambiar"} value={cambiar}/>
        <label>lastName:</label>
        <input onChange={(e)=>handleChange(e)} type={"text"} name={"apellido"} value={apellido}/>
        <label>email:</label>
        <input onChange={(e)=>handleChange(e)} type={"email"} name={"email"} value={email}/>
        <label>password:</label>
        <input onChange={(e)=>handleChange(e)} type={"password"} name={"clave"} value={clave}/>
        <label>comfirmPassword:</label>
        <input onChange={(e)=>handleChange(e)} type={"password"} name={"validar"} value={validar}/>
        <button>aplicar</button>
      </form>
      <p>{cambiar}</p>
      <p>{apellido}</p>
      <p>{email}</p>
      <p>{clave}</p>
      <p>{validar}</p>

      <Simple message={""}/>
      <Simple message={""}/>
    </div>

  )
}
export default App;
